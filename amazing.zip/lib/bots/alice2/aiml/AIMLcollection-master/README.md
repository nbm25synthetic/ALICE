# AIMLcollection

A huge collection of AIML files. You'll find anything you want here to help you build your own AIML brain! good luck!



#### by

* [Karrar S. Honi](https://github.com/karrarkazuya)
