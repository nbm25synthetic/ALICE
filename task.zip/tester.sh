#!/bin/sh

rm ./logs/chat/Anna/chat.log
rm ./logs/chat/Anna/chat.xml
# ./server.sh < testcase.txt
